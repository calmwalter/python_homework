from dequeue import *
dq=deque()
dq.modeifySize(10)
dq.addLeft(5)
dq.addRight(4)
print(dq.displayNumber())
dq.popLeft()
print(dq.displayNumber())
dq.modeifySize(20)

