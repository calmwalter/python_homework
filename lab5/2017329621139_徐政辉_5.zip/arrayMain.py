from Array import *
x=[1,2,3]
a=Array(x)
b=a*3
print(b.elements)

c=a+b
print(c.elements)

d=c-a
print(d.elements)

e=b/2
print(e.elements)

print(a==b)